=== CTL Halloween Memory ===
Tags: brain game, halloween, card, game, HTML5 memory, memory game, puzzle, skill, strategy, kids game, children game, card game,seasonal, seasonal game, halloween game
Requires at least: 4.3
Tested up to: 4.3

Add Halloween Memory to CTL Arcade plugin

== Description ==
Add Halloween Memory to CTL Arcade plugin


	